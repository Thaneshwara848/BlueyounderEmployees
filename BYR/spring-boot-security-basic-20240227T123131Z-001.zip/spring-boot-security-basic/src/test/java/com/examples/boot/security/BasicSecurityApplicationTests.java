package com.examples.boot.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BasicSecurityApplicationTests {

	@Test
	public void contextLoads() {
	}

}
