package com.blueyounder.SBadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBadminApplication {

	public static void main(String[] args) {
		SpringApplication.run(SBadminApplication.class, args);
	}

}
