"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Demo6 = void 0;
var Demo6 = /** @class */ (function () {
    function Demo6() {
    }
    Demo6.prototype.display = function () {
        console.log("Method from Demo6 ");
    };
    return Demo6;
}());
exports.Demo6 = Demo6;
