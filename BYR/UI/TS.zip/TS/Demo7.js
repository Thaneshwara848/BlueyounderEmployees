"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Demo6_1 = require("./Demo6");
var Demo7 = /** @class */ (function () {
    function Demo7() {
    }
    return Demo7;
}());
var v6 = new Demo6_1.Demo6();
v6.display();
