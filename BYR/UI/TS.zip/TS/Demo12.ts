import {Demo11} from './Demo11'
class Demo12
{
    constructor()
    {
    }
}

var d12= new Demo11();
d12.display();
