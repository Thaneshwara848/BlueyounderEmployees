class Demo8{
    constructor(id,name,age)
    {
        console.log("ID :"+id)
        console.log("Name :"+name)
        console.log("Age :")
    }
    display()
    {
        console.log("Hi method....!")
    }
}
var d= new Demo8("Anup","200",35);
d.display();