
class Demo16
{
    constructor()
    {
        console.log("Demo 6 const")
    }
    display(){
            console.log("Method from Demo6 ")
    }
}