class Demo1
{

    constructor(){
      // let firstName: string = "Thanesh";
       //let firstName = "Thanesh";
       // console.log(typeof(firstName))

       let firstName: string = "Thanesh";
    //    firstName = 30; not allowed 

//     const names: string[] = ["Apple","Banana","Cherry","Jack"];
//     for(var i=0;i<names.length;i++)
//     {
//         console.log(names[i])
//     }
//    // names.push("Pineapple");
// //    names.push(10); we cant add number if its a string array 
//     console.log("============================")
//     for(var i=0;i<names.length;i++)
//     {
//         console.log(names[i])
//     }

// const names: readonly string[] = ["Apple","Banana","Cherry","Jack"];
//     for(var i=0;i<names.length;i++)
//     {
//         console.log(names[i])
//     }
//    // names.push("Pineapple"); we cantot re wite 
// //    names.push(10); we cant add number if its a string array 
//     console.log("============================")
//     for(var i=0;i<names.length;i++)
//     {
//         console.log(names[i])
//     }

// // Try creating a new Car using the alias provided
// type CarYear = number;
// type CarType = string;
// type CarModel = string;
// type Car = {
//   year: CarYear,
//   type: CarType,
//   model: CarModel
// };

// const carYear: CarYear = 2001
// const carType: CarType = "Toyota"
// const carModel: CarModel = "Corolla"
// const car: Car = {
//   year: carYear,
//   type: carType,
//   model: carModel
// };

console.log(car);
    }

}
var d1= new Demo1();
