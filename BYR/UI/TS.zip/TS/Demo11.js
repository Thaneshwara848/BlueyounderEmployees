"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Demo123 = exports.Demo11 = void 0;
var Demo11 = /** @class */ (function () {
    function Demo11() {
        console.log("Demo 6 const");
    }
    Demo11.prototype.display = function () {
        console.log("Method from Demo6 ");
    };
    return Demo11;
}());
exports.Demo11 = Demo11;
var Demo123 = /** @class */ (function () {
    function Demo123() {
        console.log("Demo 123 const");
    }
    Demo123.prototype.display = function () {
        console.log("Method from Demo123 ");
    };
    return Demo123;
}());
exports.Demo123 = Demo123;
