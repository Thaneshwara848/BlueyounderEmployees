var Demo1 = /** @class */ (function () {
    function Demo1() {
        // let firstName: string = "Thanesh";
        //let firstName = "Thanesh";
        // console.log(typeof(firstName))
        var firstName = "Thanesh";
        var carYear = 2001;
        var carType = "Toyota";
        var carModel = "Corolla";
        var car = {
            year: carYear,
            type: carType,
            model: carModel
        };
        console.log(car);
    }
    return Demo1;
}());
var d1 = new Demo1();
