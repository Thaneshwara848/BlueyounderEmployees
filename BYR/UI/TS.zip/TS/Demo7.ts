class Demo17
{
    constructor(){
    }
} 

var v6= new Demo16();

