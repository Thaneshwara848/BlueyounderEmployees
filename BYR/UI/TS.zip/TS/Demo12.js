"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Demo11_1 = require("./Demo11");
var Demo12 = /** @class */ (function () {
    function Demo12() {
    }
    return Demo12;
}());
var d12 = new Demo11_1.Demo11();
d12.display();
var d123 = new Demo11_1.Demo123();
d123.display();
